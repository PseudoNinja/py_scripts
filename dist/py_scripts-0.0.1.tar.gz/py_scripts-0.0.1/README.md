# py_scripts

## Description

Useful Python scripts and utilities

## Installation instructions

```
python -m pip install "https://github.com/PseudoNinja/py_scripts"
```

## Usage

### Image Service

#### ImageService.convert_tiff_to_jpeg

_Description:_ Convert TIFF files in Directory to JPEG
_Args:_

-   dir_path (str, optional): Directort path to be converted. Defaults to directory run from
